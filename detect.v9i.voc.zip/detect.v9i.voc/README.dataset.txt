# detect > 2024-02-16 7:54am
https://universe.roboflow.com/n3cr0n0m1c0n/detect-ccpuk

Provided by a Roboflow user
License: CC BY 4.0

